using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using form_submission.Models;

namespace form_submission.Controllers
{
    public class UsersController : Controller
    {
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [Route("submit_info")]
        public IActionResult SubmitInfo(string firstName, string lastName, int Age, string Email, string Password)
        {
            User newUser = new User
            {
                firstName = firstName,
                lastName = lastName,
                Age = Age,
                Email = Email,
                Password = Password
            };
            if(TryValidateModel(newUser) == false)
            {
                ViewBag.Errors = ModelState.Values;
                return View();
            }
            else
            {
                return RedirectToAction("Success");
            }
        }

        [HttpGet]
        [Route("/Success")]
        public IActionResult Success()
        {
            return View();
        }
            
    }
}
